document.getElementById("loginForm").addEventListener("submit",e=>{
e.preventDefault();
const id=userId.value.trim();
const type=userType.value;
sessionStorage.setItem("session",JSON.stringify({id,type}));
location.href=type==="student"?"student/dashboard.html":"teacher/dashboard.html";
});