export function requireLogin(role){
const s=JSON.parse(sessionStorage.getItem("session"));
if(!s||s.type!==role)location.href="../login.html";
}
export function logout(){
sessionStorage.removeItem("session");
location.href="../login.html";
}